const settings = {
  packname: '⭐',
  author: '⭐',
  botName: "⭐",
  botOwner: 'eri!', // Your name
  ownerNumber: '447878935454', //Your number
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "YLLI-MD.",
  version: "0.6.9",
};

module.exports = settings;
