
const fs = require('fs')

async function printkamCommand(sock, chatId, senderId) {
    try {
        await sock.sendMessage(chatId, { 
            image: fs.readFileSync('./assets/download.webp'),
            caption: 'kamilla kabello!'
        })
    } catch (error) {
        console.error('Error in printkam command:', error)
        await sock.sendMessage(chatId, { text: 'Failed to send image' })
    }
}

module.exports = printkamCommand
