const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, channelLink) {
    const helpMessage = `

   * ${settings.botName || '⭐'}*  
   Version: *${settings.version || '0.6.9'}*
   by ${settings.botOwner || 'eri!'}


📌 Comandi Disponibili

🌍 Generali  
➤ .help / .menu  
➤ .ping  
➤ .alive  
➤ .tts <testo>  
➤ .owner  
➤ .weather <città>  
➤ .attp <testo>  
➤ .groupinfo  
➤ .staff / .admins  
➤ .vv  

🎨 Immagini & Sticker  
➤ .simage (da sticker a immagine)  
➤ .sticker (da immagine a sticker)  

🛠️ Admin  
➤ .ban @user | .kick @user  
➤ .promote @user  
➤ .mute <minuti> | .unmute  
➤ .delete / .del  
➤ .warnings @user | .warn @user  
➤ .antilink | .antibadword  
➤ .clear  
➤ .tag <messaggio> | .tagall  
➤ .chatbot  
➤ .resetlink  

👑 Proprietario  
➤ .mode  
➤ .autostatus  
➤ .clearsession  

🎵 Downloader  
➤ .play <canzone>  
➤ .song <canzone>  

`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');

        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);

            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterName: '⭐',
                    }
                }
            });
        } else {
            console.error('Bot image not found at:', imagePath);
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterName: '⭐',
            
                    } 
                }
            });
        }
    } catch (error) {
        console.error('Errore nel comando di aiuto:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;