async function aliveCommand(sock, chatId) {
    try {
        const message = `*⭐ è Attivo!*\n\n` +
                       `*Versione:* 0.6.9\n` +
                       `*Stato:* Online\n` +
                       `*Modalità:* Pubblica\n\n` +
                       `Digita *.menu* per l'elenco completo dei comandi`;

        await sock.sendMessage(chatId, {
            text: message,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '⭐',
                    newsletterName: ' ⭐',
                    serverMessageId: -1
                }
            }
        });
    } catch (error) {
        console.error('Error:', error);
        await sock.sendMessage(chatId, { text: 'La stella si è spenta!' });
    }
}

module.exports = aliveCommand;