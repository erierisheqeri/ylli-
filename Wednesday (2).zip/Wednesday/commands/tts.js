const gTTS = require('gtts');
const fs = require('fs');
const path = require('path');

async function ttsCommand(sock, chatId, text, language = 'en') {
    if (!text) {
        await sock.sendMessage(chatId, { text: 'Si prega di fornire il testo per la conversione in text to speech.' });
        return;
    }

    const fileName = `tts-${Date.now()}.mp3`;
    const filePath = path.join(__dirname, '..', 'assets', fileName);

    const gtts = new gTTS(text, language);
    gtts.save(filePath, async function (err) {
        if (err) {
            await sock.sendMessage(chatId, { text: 'Errore nella generazione dell\'audio TTS.' });
            return;
        }

        await sock.sendMessage(chatId, {
            audio: { url: filePath },
            mimetype: 'audio/mpeg'
        });

        fs.unlinkSync(filePath);
    });
}

module.exports = ttsCommand;
