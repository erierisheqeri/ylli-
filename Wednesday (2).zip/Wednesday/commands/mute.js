const isAdmin = require('../helpers/isAdmin');

async function muteCommand(sock, chatId, senderId, durationInMinutes) {
    console.log(`Tentativo di silenziare il gruppo per ${durationInMinutes} minuti.`); // Log per il debug

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
    if (!isBotAdmin) {
        await sock.sendMessage(chatId, { text: 'Per favore, rendi prima il bot amministratore.' });
        return;
    }

    if (!isSenderAdmin) {
        await sock.sendMessage(chatId, { text: 'Solo gli amministratori del gruppo possono usare il comando di silenziamento.' });
        return;
    }

    const durationInMilliseconds = durationInMinutes * 60 * 1000;
    try {
        await sock.groupSettingUpdate(chatId, 'announcement'); // Silenzia il gruppo
        await sock.sendMessage(chatId, { text: `Il gruppo è stato silenziato per ${durationInMinutes} minuti.` });

        setTimeout(async () => {
            await sock.groupSettingUpdate(chatId, 'not_announcement'); // Disattiva il silenziamento dopo la durata
            await sock.sendMessage(chatId, { text: 'Il gruppo è stato riattivato.' });
        }, durationInMilliseconds);
    } catch (error) {
        console.error('Errore nel silenziare/riattivare il gruppo:', error);
        await sock.sendMessage(chatId, { text: 'Si è verificato un errore durante il silenziamento/riattivazione del gruppo. Riprova.' });
    }
}

module.exports = muteCommand;
