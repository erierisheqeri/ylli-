const axios = require('axios');
const settings = require('../settings'); // Assuming the API key is stored here

async function gifCommand(sock, chatId, query) {
    const apiKey = settings.giphyApiKey; // Replace with your Giphy API Key

    if (!query) {
        await sock.sendMessage(chatId, { text: 'Per favore, fornisci un termine di ricerca per la GIF.' });
        return;
    }

    try {
        const response = await axios.get(`https://api.giphy.com/v1/gifs/search`, {
            params: {
                api_key: apiKey,
                q: query,
                limit: 1,
                rating: 'g'
            }
        });

        const gifUrl = response.data.data[0]?.images?.downsized_medium?.url;

        if (gifUrl) {
            await sock.sendMessage(chatId, { video: { url: gifUrl }, caption: `Ecco la tua GIF per "${query}"` });
        } else {
            await sock.sendMessage(chatId, { text: 'Nessuna GIF trovata per il tuo termine di ricerca.' });
        }
    } catch (error) {
        console.error('Errore durante il recupero della GIF:', error);
        await sock.sendMessage(chatId, { text: 'Impossibile recuperare la GIF. Riprova più tardi.' });
    }
}

module.exports = gifCommand;
