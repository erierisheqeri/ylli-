const { isAdmin } = require('../helpers/isAdmin');

async function demoteCommand(sock, chatId, mentionedJids, message) {
    try {
        // First check if it's a group
        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { 
                text: 'Questo comando può essere utilizzato solo nei gruppi!'
            });
            return;
        }

        // Check admin status first, before any other operations
        try {
            const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, message.key.participant || message.key.remoteJid);
            
            if (!isBotAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '❌ Errore: Per favore rendi il bot amministratore prima di utilizzare questo comando.'
                });
                return;
            }

            if (!isSenderAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '❌ Errore: Solo gli amministratori del gruppo possono utilizzare il comando di declassamento.'
                });
                return;
            }
        } catch (adminError) {
            console.error('Errore nel controllo dello stato di amministratore:', adminError);
            await sock.sendMessage(chatId, { 
                text: '❌ Errore: Assicurati che il bot sia amministratore di questo gruppo.'
            });
            return;
        }

        let userToDemote = [];
        
        // Check for mentioned users
        if (mentionedJids && mentionedJids.length > 0) {
            userToDemote = mentionedJids;
        }
        // Check for replied message
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToDemote = [message.message.extendedTextMessage.contextInfo.participant];
        }
        
        // If no user found through either method
        if (userToDemote.length === 0) {
            await sock.sendMessage(chatId, { 
                text: '❌ Errore: Per favore menziona l\'utente o rispondi al suo messaggio per declassarlo!'
            });
            return;
        }

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        await sock.groupParticipantsUpdate(chatId, userToDemote, "demote");
        
        // Get usernames for each demoted user
        const usernames = await Promise.all(userToDemote.map(async jid => {
            return `@${jid.split('@')[0]}`;
        }));

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        const demotionMessage = `*back to the lobby my nigga...*\n\n` +
            `👤 *Utente${userToDemote.length > 1 ? 'i' : ''} declassato${userToDemote.length > 1 ? 'i' : ''}:*\n` +
            `${usernames.map(name => `• ${name}`).join('\n')}\n\n` +
            `👑 *Declassato da:* @${message.key.participant ? message.key.participant.split('@')[0] : message.key.remoteJid.split('@')[0]}\n\n` +
            `📅 *Data:* ${new Date().toLocaleString()}`;
        
        await sock.sendMessage(chatId, { 
            text: demotionMessage,
            mentions: [...userToDemote, message.key.participant || message.key.remoteJid]
        });
    } catch (error) {
        console.error('Errore nel comando di declassamento:', error);
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            try {
                await sock.sendMessage(chatId, { 
                    text: '❌ Limite di frequenza raggiunto. Per favore riprova tra qualche secondo.'
                });
            } catch (retryError) {
                console.error('Errore nell\'invio del messaggio di riprova:', retryError);
            }
        } else {
            try {
                await sock.sendMessage(chatId, { 
                    text: '❌ Impossibile declassare l\'utente/gli utenti. Assicurati che il bot sia amministratore e abbia le autorizzazioni sufficienti.'
                });
            } catch (sendError) {
                console.error('Errore nell\'invio del messaggio di errore:', sendError);
            }
        }
    }
}

// Function to handle automatic demotion detection
async function handleDemotionEvent(sock, groupId, participants, author) {
    try {
        if (!groupId || !participants) {
            console.log('groupId o partecipanti non validi:', { groupId, participants });
            return;
        }

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Get usernames for demoted participants
        const demotedUsernames = await Promise.all(participants.map(async jid => {
            return `@${jid.split('@')[0]}`;
        }));

        let demotedBy;
        let mentionList = [...participants];

        if (author && author.length > 0) {
            // Ensure author has the correct format
            const authorJid = author;
            demotedBy = `@${authorJid.split('@')[0]}`;
            mentionList.push(authorJid);
        } else {
            demotedBy = 'Sistema';
        }

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        const demotionMessage = `*!!!*\n\n` +
            `👤 *Utente${participants.length > 1 ? 'i' : ''} declassato${participants.length > 1 ? 'i' : ''}:*\n` +
            `${demotedUsernames.map(name => `• ${name}`).join('\n')}\n\n` +
            `👑 *Declassato da:* ${demotedBy}\n\n` +
            `📅 *Data:* ${new Date().toLocaleString()}`;
        
        await sock.sendMessage(groupId, {
            text: demotionMessage,
            mentions: mentionList
        });
    } catch (error) {
        console.error('Errore nella gestione dell\'evento di declassamento:', error);
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
    }
}

module.exports = { demoteCommand, handleDemotionEvent };
