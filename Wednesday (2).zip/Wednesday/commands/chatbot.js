const { setChatbot, getChatbot, removeChatbot } = require('../sql');
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');

// Load chatbot config
function loadChatbotConfig(groupId) {
    try {
        const configPath = path.join(__dirname, '../data/chatbot.json');
        if (!fs.existsSync(configPath)) {
            return null;
        }
        const data = JSON.parse(fs.readFileSync(configPath));
        return data[groupId];
    } catch (error) {
        console.error('❌ Error loading chatbot config:', error.message);
        return null;
    }
}

async function handleChatbotCommand(sock, chatId, message, match) {
    if (!match) {
        return sock.sendMessage(chatId, {
            text: `*CHATBOT SETUP*\n\n*.chatbot on*\nAbilita chatbot\n\n*.chatbot off*\nDisabilita chatbot in questo gruppo`
        });
    }

    if (match === 'on') {
        const existingConfig = await getChatbot(chatId);
        if (existingConfig?.enabled) {
            return sock.sendMessage(chatId, { text: '*Il chatbot è già abilitato per questo gruppo*' });
        }
        await setChatbot(chatId, true);
        console.log(`✅ Impostazioni chatbot aggiornate per il gruppo ${chatId}`);
        return sock.sendMessage(chatId, { text: '*Il chatbot è stato abilitato per questo gruppo*' });
    }

    if (match === 'off') {
        const config = await getChatbot(chatId);
        if (!config?.enabled) {
            return sock.sendMessage(chatId, { text: '*Il chatbot è già disabilitato per questo gruppo*' });
        }
        await removeChatbot(chatId);
        console.log(`✅ Impostazioni chatbot aggiornate per il gruppo ${chatId}`);
        return sock.sendMessage(chatId, { text: '*Il chatbot è stato disabilitato per questo gruppo*' });
    }

    return sock.sendMessage(chatId, { text: '*Comando non valido. Usa .chatbot per vedere l\'utilizzo*' });
}

async function handleChatbotResponse(sock, chatId, message, userMessage, senderId) {
    const config = loadChatbotConfig(chatId);
    if (!config?.enabled) return;

    try {
        // Debug logs
        console.log('Starting chatbot response handler');
        console.log('Chat ID:', chatId);
        console.log('User Message:', userMessage);

        // Get bot's ID
        const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        console.log('Bot Number:', botNumber);

        // Check for mentions and replies
        let isBotMentioned = false;
        let isReplyToBot = false;

        // Check if message is a reply and contains bot mention
        if (message.message?.extendedTextMessage) {
            const mentionedJid = message.message.extendedTextMessage.contextInfo?.mentionedJid || [];
            const quotedParticipant = message.message.extendedTextMessage.contextInfo?.participant;
            
            // Check if bot is mentioned in the reply
            isBotMentioned = mentionedJid.some(jid => jid === botNumber);
            
            // Check if replying to bot's message
            isReplyToBot = quotedParticipant === botNumber;
            
            console.log('Message is a reply with mention:', {
                mentionedJid,
                quotedParticipant,
                isBotMentioned,
                isReplyToBot
            });
        }
        // Also check regular mentions in conversation
        else if (message.message?.conversation) {
            isBotMentioned = userMessage.includes(`@${botNumber.split('@')[0]}`);
        }

        if (!isBotMentioned && !isReplyToBot) {
            console.log('Bot not mentioned or replied to');
            return;
        }

        // Clean the message
        let cleanedMessage = userMessage;
        if (isBotMentioned) {
            cleanedMessage = cleanedMessage.replace(new RegExp(`@${botNumber.split('@')[0]}`, 'g'), '').trim();
        }

        // Get GPT-3 response
        const response = await getGPT3Response(cleanedMessage || "hi");
        console.log('GPT-3 Response:', response);

        if (!response) {
            await sock.sendMessage(chatId, { 
                text: "Non sono riuscito a elaborare la tua richiesta al momento.",
                quoted: message
            });
            return;
        }

        // Send response as a reply with mention
        await sock.sendMessage(chatId, {
            text: `@${senderId.split('@')[0]} ${response}`,
            quoted: message,
            mentions: [senderId]
        });

        // Only log successful responses
        console.log(`✅ Chatbot responded in group ${chatId}`);
    } catch (error) {
        console.error('❌ Error in chatbot response:', error.message);
        await sock.sendMessage(chatId, { 
            text: "Mi dispiace, ho riscontrato un errore durante l'elaborazione del tuo messaggio.",
            quoted: message,
            mentions: [senderId]
        });
    }
}

async function getGPT3Response(userMessage) {
    try {
        console.log('Getting GPT-3 response for:', userMessage);
        
        const systemPrompt = {
            role: "system",
            content: "Sei YLLI CHATBOT, un assistente intelligente e ricco di funzionalità. Comportati come un essere umano e parla come un essere umano. Comprendi come il mittente risponde, comportati di conseguenza. Migliora le tue risposte con emoji pertinenti quando appropriato mantenendo chiarezza e professionalità."
        };

        const userPrompt = {
            role: "user",
            content: userMessage
        };

        const response = await fetch("https://api.yanzbotz.live/api/ai/gpt3", {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ 
                messages: [systemPrompt, userPrompt] 
            })
        });

        if (!response.ok) {
            console.error('GPT-3 API response not ok:', response.status);
            throw new Error("API call failed");
        }

        const data = await response.json();
        console.log('GPT-3 API response:', data);
        return data.result;

    } catch (error) {
        console.error("GPT-3 API error:", error);
        return null;
    }
}

module.exports = {
    handleChatbotCommand,
    handleChatbotResponse
}; 