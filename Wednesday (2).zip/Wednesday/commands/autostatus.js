const fs = require('fs');
const path = require('path');
const isOwner = require('../helpers/isOwner');

const channelInfo = {
    contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '⭐',
            newsletterName: '⭐',
            serverMessageId: -1
        }
    }
};

// Percorso per memorizzare la configurazione dello stato automatico
const configPath = path.join(__dirname, '../data/autoStatus.json');

// Inizializza il file di configurazione se non esiste
if (!fs.existsSync(configPath)) {
    fs.writeFileSync(configPath, JSON.stringify({ enabled: false }));
}

async function autoStatusCommand(sock, chatId, senderId, args) {
    try {
        // Controlla se il mittente è il proprietario
        if (!isOwner(senderId)) {
            await sock.sendMessage(chatId, { 
                text: '❌ Questo comando può essere utilizzato solo dal proprietario!',
                ...channelInfo
            });
            return;
        }

        // Leggi la configurazione corrente
        let config = JSON.parse(fs.readFileSync(configPath));

        // Se non ci sono argomenti, mostra lo stato corrente
        if (!args || args.length === 0) {
            const status = config.enabled ? 'abilitato' : 'disabilitato';
            await sock.sendMessage(chatId, { 
                text: `🔄 *Visualizzazione dello stato automatico*\n\nStato corrente: ${status}\n\nUtilizzare:\n.autostatus on - Abilita la visualizzazione dello stato automatico\n.autostatus off - Disabilita la visualizzazione dello stato automatico`,
                ...channelInfo
            });
            return;
        }

        // Gestisci i comandi on/off
        const command = args[0].toLowerCase();
        if (command === 'on') {
            config.enabled = true;
            fs.writeFileSync(configPath, JSON.stringify(config));
            await sock.sendMessage(chatId, { 
                text: '✅ La visualizzazione dello stato automatico è stata abilitata!\nIl bot ora visualizzerà automaticamente tutti gli stati dei contatti.',
                ...channelInfo
            });
        } else if (command === 'off') {
            config.enabled = false;
            fs.writeFileSync(configPath, JSON.stringify(config));
            await sock.sendMessage(chatId, { 
                text: '❌ La visualizzazione dello stato automatico è stata disabilitata!\nIl bot non visualizzerà più automaticamente gli stati.',
                ...channelInfo
            });
        } else {
            await sock.sendMessage(chatId, { 
                text: '❌ Comando non valido! Utilizzare:\n.autostatus on - Abilita la visualizzazione dello stato automatico\n.autostatus off - Disabilita la visualizzazione dello stato automatico',
                ...channelInfo
            });
        }

    } catch (error) {
        console.error('Errore nel comando autostatus:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ Si è verificato un errore durante la gestione dello stato automatico!\n' + error.message,
            ...channelInfo
        });
    }
}

// Funzione per controllare se lo stato automatico è abilitato
function isAutoStatusEnabled() {
    try {
        const config = JSON.parse(fs.readFileSync(configPath));
        return config.enabled;
    } catch (error) {
        console.error('Errore nel controllo della configurazione dello stato automatico:', error);
        return false;
    }
}

// Funzione per gestire gli aggiornamenti di stato
async function handleStatusUpdate(sock, status) {
    try {
        if (!isAutoStatusEnabled()) {
            console.log('❌ La visualizzazione dello stato automatico è disabilitata');
            return;
        }

        // Aggiungi un ritardo per evitare il limite di frequenza
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Gestisci lo stato da messages.upsert
        if (status.messages && status.messages.length > 0) {
            const msg = status.messages[0];
            if (msg.key && msg.key.remoteJid === 'status@broadcast') {
                try {
                    await sock.readMessages([msg.key]);
                    const sender = msg.key.participant || msg.key.remoteJid;
                    console.log(`✅ Stato visualizzato `);
                } catch (err) {
                    if (err.message?.includes('rate-overlimit')) {
                        console.log('⚠️ Limite di frequenza raggiunto, in attesa prima di riprovare...');
                        await new Promise(resolve => setTimeout(resolve, 2000));
                        await sock.readMessages([msg.key]);
                    } else {
                        throw err;
                    }
                }
                return;
            }
        }

        // Gestisci gli aggiornamenti di stato diretti
        if (status.key && status.key.remoteJid === 'status@broadcast') {
            try {
                await sock.readMessages([status.key]);
                const sender = status.key.participant || status.key.remoteJid;
                console.log(`✅ Stato visualizzato da: ${sender.split('@')[0]}`);
            } catch (err) {
                if (err.message?.includes('rate-overlimit')) {
                    console.log('⚠️ Limite di frequenza raggiunto, in attesa prima di riprovare...');
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    await sock.readMessages([status.key]);
                } else {
                    throw err;
                }
            }
            return;
        }

        // Gestisci lo stato nelle reazioni
        if (status.reaction && status.reaction.key.remoteJid === 'status@broadcast') {
            try {
                await sock.readMessages([status.reaction.key]);
                const sender = status.reaction.key.participant || status.reaction.key.remoteJid;
                console.log(`✅ Stato visualizzato da: ${sender.split('@')[0]}`);
            } catch (err) {
                if (err.message?.includes('rate-overlimit')) {
                    console.log('⚠️ Limite di frequenza raggiunto, in attesa prima di riprovare...');
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    await sock.readMessages([status.reaction.key]);
                } else {
                    throw err;
                }
            }
            return;
        }

    } catch (error) {
        console.error('❌ Errore nella visualizzazione dello stato automatico:', error.message);
    }
}

module.exports = {
    autoStatusCommand,
    handleStatusUpdate
}; 