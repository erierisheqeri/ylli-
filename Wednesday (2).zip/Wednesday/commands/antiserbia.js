module.exports = {
  name: 'antiserbia',
  description: 'Deletes messages containing "Serbia"',
  async execute(message) {
    if (message.content.toLowerCase().includes('serbia')) {
      try {
        await message.delete(); // Ensure waiting for the message deletion
        await message.channel.send('Devono morire tutti!'); // Wait for sending confirmation
      } catch (error) {
        console.error('Error deleting message or sending response:', error);
      }
    }
  },
};