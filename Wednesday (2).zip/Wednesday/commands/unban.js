const fs = require('fs');
const path = require('path');
const { channelInfo } = require('../config/messageConfig');

async function unbanCommand(sock, chatId, message) {
    let userToUnban;
    
    // Check for mentioned users
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToUnban = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    // Check for replied message
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToUnban = message.message.extendedTextMessage.contextInfo.participant;
    }
    
    if (!userToUnban) {
        await sock.sendMessage(chatId, { 
            text: 'Per favore, menziona l\'utente o rispondi al suo messaggio per sbannare!', 
            ...channelInfo 
        });
        return;
    }

    try {
        const bannedUsers = JSON.parse(fs.readFileSync('./database/banned.json'));
        const index = bannedUsers.indexOf(userToUnban);
        if (index > -1) {
            bannedUsers.splice(index, 1);
            fs.writeFileSync('./database/banned.json', JSON.stringify(bannedUsers, null, 2));
            
            await sock.sendMessage(chatId, { 
                text: `Sban riuscito di ${userToUnban.split('@')[0]}!`,
                mentions: [userToUnban],
                ...channelInfo 
            });
        } else {
            await sock.sendMessage(chatId, { 
                text: `${userToUnban.split('@')[0]} non è bannato!`,
                mentions: [userToUnban],
                ...channelInfo 
            });
        }
    } catch (error) {
        console.error('Errore nel comando di sban:', error);
        await sock.sendMessage(chatId, { text: 'Impossibile sbannare l\'utente!', ...channelInfo });
    }
}

module.exports = unbanCommand; 