const isAdmin = require('../helpers/isAdmin');

async function kickCommand(sock, chatId, senderId, mentionedJids, message) {
    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

    if (!isBotAdmin) {
        await sock.sendMessage(chatId, { text: 'Per favore, rendi prima il bot amministratore.' });
        return;
    }

    if (!isSenderAdmin) {
        await sock.sendMessage(chatId, { text: 'Solo gli amministratori del gruppo possono utilizzare il comando kick.' });
        return;
    }

    let usersToKick = [];
    
    // Check for mentioned users
    if (mentionedJids && mentionedJids.length > 0) {
        usersToKick = mentionedJids;
    }
    // Check for replied message
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        usersToKick = [message.message.extendedTextMessage.contextInfo.participant];
    }
    
    // If no user found through either method
    if (usersToKick.length === 0) {
        await sock.sendMessage(chatId, { 
            text: 'Per favore, menziona l\'utente o rispondi al suo messaggio per espellerlo!'
        });
        return;
    }

    try {
        await sock.groupParticipantsUpdate(chatId, usersToKick, "remove");
        
        // Get usernames for each kicked user
        const usernames = await Promise.all(usersToKick.map(async jid => {
            return `@${jid.split('@')[0]}`;
        }));
        
        await sock.sendMessage(chatId, { 
            text: `${usernames.join(', ')} è stato espulso correttamente!`,
            mentions: usersToKick
        });
    } catch (error) {
        console.error('Errore nel comando kick:', error);
        await sock.sendMessage(chatId, { 
            text: 'Impossibile espellere l\'utente!'
        });
    }
}

module.exports = kickCommand;
