
const fs = require('fs');
const path = require('path');
const isAdmin = require('../helpers/isAdmin');

// Define paths
const databaseDir = path.join(process.cwd(), 'database');
const warningsPath = path.join(databaseDir, 'warnings.json');

// Initialize warnings file if it doesn't exist
function initializeWarningsFile() {
    // Create database directory if it doesn't exist
    if (!fs.existsSync(databaseDir)) {
        fs.mkdirSync(databaseDir, { recursive: true });
    }
    
    // Create warnings.json if it doesn't exist
    if (!fs.existsSync(warningsPath)) {
        fs.writeFileSync(warningsPath, JSON.stringify({}), 'utf8');
    }
}

async function warnCommand(sock, chatId, senderId, mentionedJids, message) {
    try {
        // Initialize files first
        initializeWarningsFile();

        // First check if it's a group
        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { 
                text: 'Questo comando può essere utilizzato solo nei gruppi!'
            });
            return;
        }

        // Check admin status first
        try {
            const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
            
            if (!isBotAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '❌ Errore: Per favore, rendi il bot amministratore prima di utilizzare questo comando.'
                });
                return;
            }

            if (!isSenderAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '❌ Errore: Solo gli amministratori del gruppo possono utilizzare il comando warn.'
                });
                return;
            }
        } catch (adminError) {
            console.error('Errore nel controllo dello stato admin:', adminError);
            await sock.sendMessage(chatId, { 
                text: '❌ Errore: Assicurati che il bot sia amministratore di questo gruppo.'
            });
            return;
        }

        let userToWarn;
        
        // Check for mentioned users
        if (mentionedJids && mentionedJids.length > 0) {
            userToWarn = mentionedJids[0];
        }
        // Check for replied message
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToWarn = message.message.extendedTextMessage.contextInfo.participant;
        }
        
        if (!userToWarn) {
            await sock.sendMessage(chatId, { 
                text: '❌ Errore: Menziona l\'utente o rispondi al suo messaggio per avvertirlo!'
            });
            return;
        }

        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        try {
            // Read warnings, create empty object if file is empty
            let warnings = {};
            try {
                warnings = JSON.parse(fs.readFileSync(warningsPath, 'utf8'));
            } catch (error) {
                warnings = {};
            }

            // Initialize nested objects if they don't exist
            if (!warnings[chatId]) warnings[chatId] = {};
            if (!warnings[chatId][userToWarn]) warnings[chatId][userToWarn] = 0;
            
            warnings[chatId][userToWarn]++;
            fs.writeFileSync(warningsPath, JSON.stringify(warnings, null, 2));

            const warningMessage = `*『 AVVISO DI AVVERTIMENTO 』*\n\n` +
                `👤 *Utente Avvertito:* @${userToWarn.split('@')[0]}\n` +
                `⚠️ *Numero di Avvertimenti:* ${warnings[chatId][userToWarn]}/3\n` +
                `👑 *Avvertito Da:* @${senderId.split('@')[0]}\n\n` +
                `📅 *Data:* ${new Date().toLocaleString()}`;

            await sock.sendMessage(chatId, { 
                text: warningMessage,
                mentions: [userToWarn, senderId]
            });

            // Auto-kick after 3 warnings
            if (warnings[chatId][userToWarn] >= 3) {
                // Add delay to avoid rate limiting
                await new Promise(resolve => setTimeout(resolve, 1000));

                await sock.groupParticipantsUpdate(chatId, [userToWarn], "remove");
                delete warnings[chatId][userToWarn];
                fs.writeFileSync(warningsPath, JSON.stringify(warnings, null, 2));
                
                const kickMessage = `*『 ESPULSIONE AUTOMATICA 』*\n\n` +
                    `@${userToWarn.split('@')[0]} è stato rimosso dal gruppo dopo aver ricevuto 3 avvertimenti! ⚠️`;

                await sock.sendMessage(chatId, { 
                    text: kickMessage,
                    mentions: [userToWarn]
                });
            }
        } catch (error) {
            console.error('Errore nel comando warn:', error);
            await sock.sendMessage(chatId, { 
                text: '❌ Impossibile avvertire l\'utente!'
            });
        }
    } catch (error) {
        console.error('Errore nel comando warn:', error);
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            try {
                await sock.sendMessage(chatId, { 
                    text: '❌ Limite di velocità raggiunto. Riprova tra qualche secondo.'
                });
            } catch (retryError) {
                console.error('Errore nell\'invio del messaggio di riprovare:', retryError);
            }
        } else {
            try {
                await sock.sendMessage(chatId, { 
                    text: '❌ Impossibile avvertire l\'utente. Assicurati che il bot sia amministratore e abbia i permessi sufficienti.'
                });
            } catch (sendError) {
                console.error('Errore nell\'invio del messaggio di errore:', sendError);
            }
        }
    }
}

module.exports = warnCommand;
