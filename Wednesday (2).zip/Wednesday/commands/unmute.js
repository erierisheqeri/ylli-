async function unmuteCommand(sock, chatId) {
    await sock.groupSettingUpdate(chatId, 'not_announcement'); // Il gruppo è stato smorzato
    await sock.sendMessage(chatId, { text: 'Parlate ebrei!' });
}

module.exports = unmuteCommand;
