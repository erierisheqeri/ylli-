const { bots } = require('../lib/antilink');
const { setAntilink, getAntilink, removeAntilink } = require('../sql');
const isAdmin = require('../helpers/isAdmin');

async function handleAntilinkCommand(sock, chatId, userMessage, senderId, isSenderAdmin) {
    try {
        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { text: '```Per gli Amministratori del Gruppo Solo!```' });
            return;
        }

        const prefix = '.';
        const args = userMessage.slice(9).toLowerCase().trim().split(' ');
        const action = args[0];

        if (!action) {
            const usage = `\`\`\`IMPOSTAZIONE ANTILINK\n\n${prefix}antilink on\n${prefix}antilink set delete | kick | warn\n${prefix}antilink off\n\`\`\``;
            await sock.sendMessage(chatId, { text: usage });
            return;
        }

        switch (action) {
            case 'on':
                const existingConfig = await getAntilink(chatId, 'on');
                if (existingConfig?.enabled) {
                    await sock.sendMessage(chatId, { text: '*_Antilink è già attivo_*' });
                    return;
                }
                const result = await setAntilink(chatId, 'on', 'delete');
                await sock.sendMessage(chatId, { 
                    text: result ? '*_Antilink è stato attivato_*' : '*_Impossibile attivare Antilink_*' 
                });
                break;

            case 'off':
                await removeAntilink(chatId, 'on');
                await sock.sendMessage(chatId, { text: '*_Antilink è stato disattivato_*' });
                break;

            case 'set':
                if (args.length < 2) {
                    await sock.sendMessage(chatId, { 
                        text: `*_Si prega di specificare un'azione: ${prefix}antilink set delete | kick | warn_*` 
                    });
                    return;
                }
                const setAction = args[1];
                if (!['delete', 'kick', 'warn'].includes(setAction)) {
                    await sock.sendMessage(chatId, { 
                        text: '*_Azione non valida. Scegli delete, kick o warn._*' 
                    });
                    return;
                }
                const setResult = await setAntilink(chatId, 'on', setAction);
                await sock.sendMessage(chatId, { 
                    text: setResult ? `*_L'azione Antilink impostata su ${setAction}_*` : '*_Impossibile impostare l\'azione Antilink_*' 
                });
                break;

            case 'get':
                const status = await getAntilink(chatId, 'on');
                const actionConfig = await getAntilink(chatId, 'on');
                await sock.sendMessage(chatId, { 
                    text: `*_Configurazione Antilink:_*\nStato: ${status ? 'ON' : 'OFF'}\nAzione: ${actionConfig ? actionConfig.action : 'Non impostato'}` 
                });
                break;

            default:
                await sock.sendMessage(chatId, { text: `*_Usa ${prefix}antilink per l'utilizzo._*` });
        }
    } catch (error) {
        console.error('Errore nel comando antilink:', error);
        await sock.sendMessage(chatId, { text: '*_Errore durante l\'elaborazione del comando antilink_*' });
    }
}

async function handleLinkDetection(sock, chatId, message, userMessage, senderId) {
    const antilinkSetting = getAntilinkSetting(chatId);
    if (antilinkSetting === 'off') return;

    console.log(`Impostazione Antilink per ${chatId}: ${antilinkSetting}`);
    console.log(`Controllo del messaggio per i link: ${userMessage}`);
    
    // Log the full message object to diagnose message structure
    console.log("Oggetto messaggio completo: ", JSON.stringify(message, null, 2));

    let shouldDelete = false;

    const linkPatterns = {
        whatsappGroup: /chat\.whatsapp\.com\/[A-Za-z0-9]{20,}/,
        whatsappChannel: /wa\.me\/channel\/[A-Za-z0-9]{20,}/,
        telegram: /t\.me\/[A-Za-z0-9_]+/,
        allLinks: /https?:\/\/[^\s]+/,
    };

    // Detect WhatsApp Group links
    if (antilinkSetting === 'whatsappGroup') {
        console.log('La protezione del link del gruppo WhatsApp è abilitata.');
        if (linkPatterns.whatsappGroup.test(userMessage)) {
            console.log('Rilevato un link del gruppo WhatsApp!');
            shouldDelete = true;
        }
    } else if (antilinkSetting === 'whatsappChannel' && linkPatterns.whatsappChannel.test(userMessage)) {
        shouldDelete = true;
    } else if (antilinkSetting === 'telegram' && linkPatterns.telegram.test(userMessage)) {
        shouldDelete = true;
    } else if (antilinkSetting === 'allLinks' && linkPatterns.allLinks.test(userMessage)) {
        shouldDelete = true;
    }

    if (shouldDelete) {
        const quotedMessageId = message.key.id; // Get the message ID to delete
        const quotedParticipant = message.key.participant || senderId; // Get the participant ID

        console.log(`Tentativo di eliminare il messaggio con id: ${quotedMessageId} dal partecipante: ${quotedParticipant}`);

        try {
            await sock.sendMessage(chatId, {
                delete: { remoteJid: chatId, fromMe: false, id: quotedMessageId, participant: quotedParticipant },
            });
            console.log(`Messaggio con ID ${quotedMessageId} eliminato correttamente.`);
        } catch (error) {
            console.error('Impossibile eliminare il messaggio:', error);
        }

        const mentionedJidList = [senderId];
        await sock.sendMessage(chatId, { text: `Avviso! @${senderId.split('@')[0]}, la pubblicazione di link non è consentita.`, mentions: mentionedJidList });
    } else {
        console.log('Nessun link rilevato o protezione non abilitata per questo tipo di link.');
    }
}

module.exports = {
    handleAntilinkCommand,
    handleLinkDetection,
};
