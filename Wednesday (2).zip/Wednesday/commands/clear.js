async function clearCommand(sock, chatId) {
    try {
        const message = await sock.sendMessage(chatId, { text: 'Cancellazione dei messaggi del bot...' });
        const messageKey = message.key; // Ottieni la chiave del messaggio appena inviato dal bot
        
        // Ora elimina il messaggio del bot
        await sock.sendMessage(chatId, { delete: messageKey });
        
    } catch (error) {
        console.error('Errore durante la cancellazione dei messaggi:', error);
        await sock.sendMessage(chatId, { text: 'Si è verificato un errore durante la cancellazione dei messaggi.' });
    }
}

module.exports = { clearCommand };
