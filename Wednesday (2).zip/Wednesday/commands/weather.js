const axios = require('axios');

module.exports = async function (sock, chatId, city) {
    try {
        const apiKey = '4902c0f2550f58298ad4146a92b65e10';  // Sostituisci con la tua chiave API OpenWeather
        const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`);
        const weather = response.data;
        const weatherText = `Meteo a ${weather.name}: ${weather.weather[0].description}. Temperatura: ${weather.main.temp}°C.`;
        await sock.sendMessage(chatId, { text: weatherText });
    } catch (error) {
        console.error('Errore nel recupero del meteo:', error);
        await sock.sendMessage(chatId, { text: 'Mi dispiace, non sono riuscito a recuperare le previsioni del tempo al momento.' });
    }
};
