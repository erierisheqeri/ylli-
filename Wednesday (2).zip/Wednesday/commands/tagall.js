const isAdmin = require('../helpers/isAdmin');  // Move isAdmin to helpers

async function tagAllCommand(sock, chatId, senderId) {
    try {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
        
        if (!isSenderAdmin && !isBotAdmin) {
            await sock.sendMessage(chatId, {
                text: 'Solo gli amministratori possono usare il comando .tagall.'
            });
            return;
        }

        // Get group metadata
        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants;

        if (!participants || participants.length === 0) {
            await sock.sendMessage(chatId, { text: 'Nessun partecipante trovato nel gruppo.' });
            return;
        }

        // Crea un messaggio con ogni membro su una nuova riga
        let message = '🔊 *Membri del gruppo:*\n\n';
        participants.forEach(participant => {
            message += `@${participant.id.split('@')[0]}\n`; // Aggiungi \n per una nuova riga
        });

        // Invia il messaggio con le menzioni
        await sock.sendMessage(chatId, {
            text: message,
            mentions: participants.map(p => p.id)
        });

    } catch (error) {
        console.error('Errore nel comando tagall:', error);
        await sock.sendMessage(chatId, { text: 'Impossibile taggare tutti i membri.' });
    }
}

module.exports = tagAllCommand;  // Esporta direttamente
