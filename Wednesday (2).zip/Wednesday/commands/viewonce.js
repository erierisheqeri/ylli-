const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const settings = require('../settings');
const fs = require('fs');
const path = require('path');

// Channel info for message context
const channelInfo = {
    contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '⭐',
            newsletterName: '⭐',
            serverMessageId: -1
        }
    }
};

async function viewOnceCommand(sock, chatId, message) {
    try {
        // Get quoted message with better error handling
        const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.viewOnceMessageV2?.message ||
                            message.message?.imageMessage ||
                            message.message?.videoMessage;

        if (!quotedMessage) {
            await sock.sendMessage(chatId, { 
                text: '❌ Per favore, rispondi a un messaggio ad una visual!',
                ...channelInfo
            });
            return;
        }

        // Enhanced view once detection
        const isViewOnceImage = quotedMessage.imageMessage?.viewOnce === true || 
                              quotedMessage.viewOnceMessage?.message?.imageMessage ||
                              message.message?.viewOnceMessage?.message?.imageMessage;

        const isViewOnceVideo = quotedMessage.videoMessage?.viewOnce === true || 
                              quotedMessage.viewOnceMessage?.message?.videoMessage ||
                              message.message?.viewOnceMessage?.message?.videoMessage;

        // Get the actual message content
        let mediaMessage;
        if (isViewOnceImage) {
            mediaMessage = quotedMessage?.imageMessage || 
                         message.message?.viewOnceMessage?.message?.imageMessage ||
                         message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.viewOnceMessageV2?.message?.imageMessage;
        } else if (isViewOnceVideo) {
            mediaMessage = quotedMessage?.videoMessage || 
                         message.message?.viewOnceMessage?.message?.videoMessage ||
                         message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.viewOnceMessageV2?.message?.videoMessage;
        }

        if (!mediaMessage) {
            console.log('Message structure:', JSON.stringify(message, null, 2));
            await sock.sendMessage(chatId, { 
                text: '❌ Non sono riuscito a rilevare il messaggio ad una visual! Assicurati di aver risposto a un\'immagine o video ad una visual.',
                ...channelInfo
            });
            return;
        }

        // Handle view once image
        if (isViewOnceImage) {
            try {
                console.log('📸 Elaborazione immagine ad una visual...');
                const stream = await downloadContentFromMessage(mediaMessage, 'image');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                const caption = mediaMessage.caption || '';

                await sock.sendMessage(chatId, { 
                    image: buffer,
                    caption: `*💀 eri! Anti ViewOnce 💀*\n\n*Tipo:* Immagine 📸\n${caption ? `*Didascalia:* ${caption}` : ''}`,
                    ...channelInfo
                });
                console.log('✅ Immagine ad una visual elaborata con successo');
                return;
            } catch (err) {
                console.error('❌ Errore durante il download dell\'immagine:', err);
                await sock.sendMessage(chatId, { 
                    text: '❌ Impossibile elaborare l\'immagine ad una visual! Errore: ' + err.message,
                    ...channelInfo
                });
                return;
            }
        }

        // Handle view once video
        if (isViewOnceVideo) {
            try {
                console.log('📹 Elaborazione video ad una visual...');

                // Create temp directory if it doesn't exist
                const tempDir = path.join(__dirname, '../temp');
                if (!fs.existsSync(tempDir)) {
                    fs.mkdirSync(tempDir);
                }

                const tempFile = path.join(tempDir, `temp_${Date.now()}.mp4`);
                const stream = await downloadContentFromMessage(mediaMessage, 'video');
                const writeStream = fs.createWriteStream(tempFile);

                for await (const chunk of stream) {
                    writeStream.write(chunk);
                }
                writeStream.end();

                // Wait for file to be written
                await new Promise((resolve) => writeStream.on('finish', resolve));

                const caption = mediaMessage.caption || '';

                await sock.sendMessage(chatId, { 
                    video: fs.readFileSync(tempFile),
                    caption: `*💀 eri! Anti ViewOnce 💀*\n\n*Tipo:* Video 📹\n${caption ? `*Didascalia:* ${caption}` : ''}`,
                    ...channelInfo
                });

                // Clean up temp file
                fs.unlinkSync(tempFile);

                console.log('✅ Video ad una visual elaborato con successo');
                return;
            } catch (err) {
                console.error('❌ Errore durante l\'elaborazione del video:', err);
                await sock.sendMessage(chatId, { 
                    text: '❌ Impossibile elaborare il video ad una visual! Errore: ' + err.message,
                    ...channelInfo
                });
                return;
            }
        }

        // If we get here, it wasn't a view once message
        await sock.sendMessage(chatId, { 
            text: '❌ Questo non è un messaggio "view once"! Per favore, rispondi a un\'immagine o video ad una visual.',
            ...channelInfo
        });

    } catch (error) {
        console.error('❌ Errore nel comando viewonce:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ Errore elaborando il messaggio ad una visual! Errore: ' + error.message,
            ...channelInfo
        });
    }
}

module.exports = viewOnceCommand;