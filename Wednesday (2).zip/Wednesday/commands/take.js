const fs = require('fs');
const path = require('path');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');
const webp = require('node-webpmux');
const crypto = require('crypto');

async function takeCommand(sock, chatId, message, args) {
    try {
        // Controlla se il messaggio è una risposta a uno sticker
        const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quotedMessage?.stickerMessage) {
            await sock.sendMessage(chatId, { text: '❌ Rispondi a uno sticker con .take <nomepacchetto>' });
            return;
        }

        // Ottieni il nome del pacchetto dagli argomenti o usa il valore predefinito
        const packname = args.join(' ') || 'KnightBot';
        const author = 'Bot';

        try {
            // Crea la directory temporanea se non esiste
            const tmpDir = path.join(__dirname, '../tmp');
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true });
            }

            // Scarica lo sticker
            const stickerBuffer = await downloadMediaMessage(
                {
                    key: message.message.extendedTextMessage.contextInfo.stanzaId,
                    message: quotedMessage,
                    messageType: quotedMessage.stickerMessage ? 'stickerMessage' : 'imageMessage'
                },
                'buffer',
                {},
                {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );

            if (!stickerBuffer) {
                await sock.sendMessage(chatId, { text: '❌ Impossibile scaricare lo sticker' });
                return;
            }

            // Converti in WebP usando sharp
            const webpBuffer = await sharp(stickerBuffer)
                .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
                .webp()
                .toBuffer();

            // Aggiungi metadati usando webpmux
            const img = new webp.Image();
            await img.load(webpBuffer);

            // Crea metadati
            const json = {
                'sticker-pack-id': crypto.randomBytes(32).toString('hex'),
                'sticker-pack-name': packname,
                'sticker-pack-publisher': author,
                'emojis': ['🤖']
            };

            // Crea buffer exif
            const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
            const jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8');
            const exif = Buffer.concat([exifAttr, jsonBuffer]);
            exif.writeUIntLE(jsonBuffer.length, 14, 4);

            // Imposta i dati exif
            img.exif = exif;

            // Ottieni il buffer finale con metadati
            const finalBuffer = await img.save(null);

            // Invia lo sticker
            await sock.sendMessage(chatId, {
                sticker: finalBuffer
            });

        } catch (error) {
            console.error('Errore durante l\'elaborazione dello sticker:', error);
            await sock.sendMessage(chatId, { text: '❌ Errore durante l\'elaborazione dello sticker' });
        }

    } catch (error) {
        console.error('Errore nel comando take:', error);
        await sock.sendMessage(chatId, { text: '❌ Errore durante l\'elaborazione del comando' });
    }
}

module.exports = takeCommand; 